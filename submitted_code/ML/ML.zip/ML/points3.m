%% Flower Classifier using a CNN
%  (C) Oge Marques, PhD - 2018

%% PART 1: Baseline Classifier
%% Create image data store
imds = imageDatastore(fullfile('C:\temp'),...
'IncludeSubfolders',true,'FileExtensions','.png','LabelSource','foldernames');

% (OPTIONAL) Count number of images per label 
labelCount = countEachLabel(imds);

%% Create training and validation sets
[imdsTrainingSet, imdsValidationSet] = splitEachLabel(imds, 0.7, 'randomize');

%% Create simple CNN 
imageSize = [299 299 1];
numClasses = 3;

netWidth = 16;
layers = [
    imageInputLayer([299 299 1],'Name','input')
    convolution2dLayer(3,netWidth,'Padding','same','Name','convInp')
    batchNormalizationLayer('Name','BNInp')
    reluLayer('Name','reluInp')
    
    convolutionalUnit(netWidth,1,'S1U1')
    additionLayer(2,'Name','add11')
    reluLayer('Name','relu11')
    convolutionalUnit(netWidth,1,'S1U2')
    additionLayer(2,'Name','add12')
    reluLayer('Name','relu12')
    
    convolutionalUnit(2*netWidth,2,'S2U1')
    additionLayer(2,'Name','add21')
    reluLayer('Name','relu21')
    convolutionalUnit(2*netWidth,1,'S2U2')
    additionLayer(2,'Name','add22')
    reluLayer('Name','relu22')
    
    convolutionalUnit(4*netWidth,2,'S3U1')
    additionLayer(2,'Name','add31')
    reluLayer('Name','relu31')
    convolutionalUnit(4*netWidth,1,'S3U2')
    additionLayer(2,'Name','add32')
    reluLayer('Name','relu32')
    
    averagePooling2dLayer(8,'Name','globalPool')
    fullyConnectedLayer(3,'Name','fcFinal')
    softmaxLayer('Name','softmax')
    classificationLayer('Name','classoutput')
    ];

lgraph = layerGraph(layers);
lgraph = connectLayers(lgraph,'reluInp','add11/in2');
lgraph = connectLayers(lgraph,'relu11','add12/in2');
skip1 = [
    convolution2dLayer(1,2*netWidth,'Stride',2,'Name','skipConv1')
    batchNormalizationLayer('Name','skipBN1')];
lgraph = addLayers(lgraph,skip1);
lgraph = connectLayers(lgraph,'relu12','skipConv1');
lgraph = connectLayers(lgraph,'skipBN1','add21/in2');
lgraph = connectLayers(lgraph,'relu21','add22/in2');
skip2 = [
    convolution2dLayer(1,4*netWidth,'Stride',2,'Name','skipConv2')
    batchNormalizationLayer('Name','skipBN2')];
lgraph = addLayers(lgraph,skip2);
lgraph = connectLayers(lgraph,'relu22','skipConv2');
lgraph = connectLayers(lgraph,'skipBN2','add31/in2');
lgraph = connectLayers(lgraph,'relu31','add32/in2');



%% Specify training options (stochastic gradient descent with momentum)
options = trainingOptions('sgdm', ...
    'Shuffle','every-epoch', ...
    'MaxEpochs',80, ...
    'ValidationData',imdsValidationSet, ...
    'ValidationFrequency',30, ...
    'Verbose',false, ...
    'MiniBatchSize',64,...
    'Plots','training-progress');

%% Train the network. 
%%net1 = trainNetwork(imdsTrainingSet,layers,options);

%% Report accuracy of baseline classifier on validation set
%%YPred = classify(net1,imdsValidationSet);
%%YValidation = imdsValidationSet.Labels;

%%imdsAccuracy = sum(YPred == YValidation)/numel(YValidation);

%% Confusion matrix
%%plotconfusion(YValidation,YPred)

%% PART 2: Baseline Classifier with Data Augmentation
%% Create augmented image data store
% Specify data augmentation options and values/ranges
imageAugmenter = imageDataAugmenter( ...
    'RandRotation',[-20,20], ...
    'RandXShear',[-2 2], ...
    'RandYShear',[-2 2], ...
    'RandYReflection',1, ...
    'RandXReflection',1);

% Apply transformations (using randmly picked values) and build augmented
% data store
augImds = augmentedImageDatastore(imageSize,imds,'DataAugmentation',imageAugmenter);

%% Create training and validation sets
[augImdsTrainingSet, augImdsValidationSet] = splitEachLabel(imds, 0.7, 'randomize');
    
%% Train the network. 
net2 = trainNetwork(augImdsTrainingSet,lgraph,options);

%% Report accuracy of baseline classifier with image data augmentation
YPred = classify(net2,augImdsValidationSet);
YValidation = augImdsValidationSet.Labels;

augImdsAccuracy = sum(YPred == YValidation)/numel(YValidation);

XPred = classify(net2,augImdsValidationSet);
XValidation = augImdsValidationSet.Labels;

[YPred,probs] = classify(net2,augImdsValidationSet);
accuracy = mean(YPred == imdsValidationSet.Labels)

%% Confusion matrix
figure, plotconfusion(YValidation,YPred)
%% 
figure('Units','normalized','Position',[0.2 0.2 0.4 0.4]);
cm = confusionchart(YValidation,YPred);
cm.Title = 'Confusion Matrix for Validation Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';
%% 
idx = randperm(numel(imdsValidationSet.Files),4);
figure
for i = 1:4
    subplot(2,2,i)
    I = readimage(imdsValidationSet,idx(i));
    imshow(I)
    label = YPred(idx(i));
    title(string(label) + ", " + num2str(100*max(probs(idx(i),:)),3) + "%");
end
%% 
function layers = convolutionalUnit(numF,stride,tag)
layers = [
    convolution2dLayer(3,numF,'Padding','same','Stride',stride,'Name',[tag,'conv1'])
    batchNormalizationLayer('Name',[tag,'BN1'])
    reluLayer('Name',[tag,'relu1'])
    convolution2dLayer(3,numF,'Padding','same','Name',[tag,'conv2'])
    batchNormalizationLayer('Name',[tag,'BN2'])];
end
