%% Flower Classifier using a CNN
%  (C) Oge Marques, PhD - 2018

%% PART 1: Baseline Classifier
%% Create image data store
imds = imageDatastore(fullfile('C:\temp'),...
'IncludeSubfolders',true,'FileExtensions','.png','LabelSource','foldernames');

% (OPTIONAL) Count number of images per label 
labelCount = countEachLabel(imds);

%% Create training and validation sets
[imdsTrainingSet, imdsValidationSet] = splitEachLabel(imds, 0.7, 'randomize');

%% Create simple CNN 
imageSize = [299 299 1];
numClasses = 3;
% Specify the convolutional neural network architecture.

%% 


layers = [
    imageInputLayer([299 299 1])
    
    convolution2dLayer(3,8,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,16,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,32,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,64,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    fullyConnectedLayer(3)
    softmaxLayer
    classificationLayer];

%% Specify training options (stochastic gradient descent with momentum)
options = trainingOptions('sgdm', ...
    'MaxEpochs',50, ...
    'ValidationData',imdsValidationSet, ...
    'ValidationFrequency',30, ...
    'Verbose',false, ...
    'MiniBatchSize',64,...
    'Plots','training-progress');

%% Train the network. 
net1 = trainNetwork(imdsTrainingSet,layers,options);

%% Report accuracy of baseline classifier on validation set
YPred = classify(net1,imdsValidationSet);
YValidation = imdsValidationSet.Labels;

imdsAccuracy = sum(YPred == YValidation)/numel(YValidation);

%% Confusion matrix
plotconfusion(YValidation,YPred)

%% PART 2: Baseline Classifier with Data Augmentation
%% Create augmented image data store
% Specify data augmentation options and values/ranges
imageAugmenter = imageDataAugmenter( ...
    'RandRotation',[-20,20], ...
    'RandXTranslation',[-5 5], ...
    'RandYTranslation',[-5 5], ...
    'RandXShear',[-2 2], ...
    'RandYShear',[-2 2], ...
    'RandYReflection',1, ...
    'RandXReflection',1);

% Apply transformations (using randmly picked values) and build augmented
% data store
augImds = augmentedImageDatastore(imageSize,imds,'DataAugmentation',imageAugmenter);

%% Create training and validation sets
[augImdsTrainingSet, augImdsValidationSet] = splitEachLabel(imds, 0.7, 'randomize');
    
%% Train the network. 
net2 = trainNetwork(augImdsTrainingSet,layers,options);

%% Report accuracy of baseline classifier with image data augmentation
YPred = classify(net2,augImdsValidationSet);
YValidation = augImdsValidationSet.Labels;

augImdsAccuracy = sum(YPred == YValidation)/numel(YValidation);

%% Confusion matrix
figure, plotconfusion(YValidation,YPred)