%% Flower Classifier using a CNN
%  (C) Oge Marques, PhD - 2018

%% PART 1: Baseline Classifier
%% Create image data store
imds = imageDatastore(fullfile('C:\temp\'),...
'IncludeSubfolders',true,'FileExtensions','.png','LabelSource','foldernames');

% (OPTIONAL) Count number of images per label 
labelCount = countEachLabel(imds);

%% Create training and validation sets
[imdsTrainingSet, imdsValidationSet] = splitEachLabel(imds, 0.8, 'randomize');

%% Create simple CNN 
imageSize = [299 299 1];
numClasses = 3;
% Specify the convolutional neural network architecture.

%% 


layers = [
    imageInputLayer([299 299 1])
    
    convolution2dLayer(3,8,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,16,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,32,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,64,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    fullyConnectedLayer(3)
    softmaxLayer
    classificationLayer];

%% Specify training options (stochastic gradient descent with momentum)
options = trainingOptions('sgdm', ...
    'MaxEpochs',100, ...
    'ValidationData',imdsValidationSet, ...
    'ValidationFrequency',30, ...
    'Verbose',false, ...
    'MiniBatchSize',64,...
    'Plots','training-progress');

%% Train the network. 
%%net1 = trainNetwork(imdsTrainingSet,layers,options);

%% Report accuracy of baseline classifier on validation set
%%YPred = classify(net1,imdsValidationSet);
%%YValidation = imdsValidationSet.Labels;

%%imdsAccuracy = sum(YPred == YValidation)/numel(YValidation);

%% Confusion matrix
%%plotconfusion(YValidation,YPred)

%% PART 2: Baseline Classifier with Data Augmentation
%% Create augmented image data store
% Specify data augmentation options and values/ranges
imageAugmenter = imageDataAugmenter( ...
    'RandRotation',[-20,20], ...
    'RandXShear',[-2 2], ...
    'RandYShear',[-2 2], ...
    'RandYReflection',1, ...
    'RandXReflection',1);

% Apply transformations (using randmly picked values) and build augmented
% data store
augImds = augmentedImageDatastore(imageSize,imds,'DataAugmentation',imageAugmenter);

%% Create training and validation sets
[augImdsTrainingSet, augImdsValidationSet] = splitEachLabel(imds, 0.8, 'randomize');
    
%% Train the network. 
net2 = trainNetwork(augImdsTrainingSet,layers,options);

%% Report accuracy of baseline classifier with image data augmentation
YPred = classify(net2,augImdsValidationSet);
YValidation = augImdsValidationSet.Labels;

augImdsAccuracy = sum(YPred == YValidation)/numel(YValidation);

XPred = classify(net2,augImdsValidationSet);
XValidation = augImdsValidationSet.Labels;

[YPred,probs] = classify(net2,augImdsValidationSet);
accuracy = mean(YPred == imdsValidationSet.Labels)

%% Confusion matrix
figure, plotconfusion(YValidation,YPred)
%% 
figure('Units','normalized','Position',[0.2 0.2 0.4 0.4]);
cm = confusionchart(YValidation,YPred);
cm.Title = 'Confusion Matrix for Validation Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';
%% 
idx = randperm(numel(imdsValidationSet.Files),4);
figure
for i = 1:4
    subplot(2,2,i)
    I = readimage(imdsValidationSet,idx(i));
    imshow(I)
    label = YPred(idx(i));
    title(string(label) + ", " + num2str(100*max(probs(idx(i),:)),3) + "%");
end