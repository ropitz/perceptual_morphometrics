imds = imageDatastore(fullfile('C:\temp'),...
'IncludeSubfolders',true,'FileExtensions','.png','LabelSource','foldernames');
tbl = countEachLabel(imds)

%% 

[trainingSet,testSet] = splitEachLabel(imds,0.6,'randomize');

bag = bagOfFeatures(imds);
%% 
categoryClassifier = trainImageCategoryClassifier(trainingSet, bag);
%% 
confMatrix = evaluate(categoryClassifier, trainingSet);
confMatrix = evaluate(categoryClassifier, testSet);
mean(diag(confMatrix))
%% 
img = imread(fullfile('C:\temp\Flowers','SW','AZ-06.png _saliencysmoothgrad.png'));
[labelIdx, scores] = predict(categoryClassifier, img);

% Display the string label
categoryClassifier.Labels(labelIdx)